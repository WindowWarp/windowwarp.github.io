# Sourced by AppRun. The AppImage uses the host's libva; tell it where the host keeps its
# VA-API drivers (radeonsi for AMD such as the Steam Deck, iHD/i965 for Intel).
if [ -z "$LIBVA_DRIVERS_PATH" ]; then
    export LIBVA_DRIVERS_PATH="/usr/lib64/dri:/usr/lib/dri:/usr/lib/x86_64-linux-gnu/dri"
fi
