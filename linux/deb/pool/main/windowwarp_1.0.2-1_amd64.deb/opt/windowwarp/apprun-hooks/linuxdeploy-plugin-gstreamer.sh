# Sourced by AppRun (replaces linuxdeploy-plugin-gstreamer's hook). Only our bundled
# GStreamer plugins are used, never the host's. AppRun runs with "set -e", so every
# line here must succeed: the stock hook ended on a failing test (no ptp-helper) and
# made the AppImage exit silently.
appdir="${APPDIR:-$this_dir}"
export GST_REGISTRY_REUSE_PLUGIN_SCANNER="no"
export GST_PLUGIN_SYSTEM_PATH_1_0="$appdir/usr/lib/gstreamer-1.0"
export GST_PLUGIN_PATH_1_0="$appdir/usr/lib/gstreamer-1.0"
export GST_PLUGIN_SCANNER_1_0="$appdir/usr/lib/gstreamer1.0/gstreamer-1.0/gst-plugin-scanner"
# own registry file, so a host GStreamer of another version never mixes in
export GST_REGISTRY_1_0="${XDG_CACHE_HOME:-$HOME/.cache}/windowwarp/gst-registry.bin"
